package com.example.clase8JPAABM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase8JpaAbmApplication {

	public static void main(String[] args) {
		SpringApplication.run(Clase8JpaAbmApplication.class, args);
	}

}
