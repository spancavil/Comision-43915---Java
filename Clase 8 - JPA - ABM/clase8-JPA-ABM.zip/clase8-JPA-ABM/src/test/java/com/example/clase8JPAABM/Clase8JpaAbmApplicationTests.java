package com.example.clase8JPAABM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase8JpaAbmApplicationTests {

	@Test
	void contextLoads() {
	}

}
